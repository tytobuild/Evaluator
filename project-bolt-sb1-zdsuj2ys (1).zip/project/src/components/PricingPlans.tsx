import React from 'react';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { Sparkles, Check, Zap, Brain, LineChart, Clock } from 'lucide-react';

const features = [
  'Unlimited AI Market Analysis',
  'Real-time Price Predictions',
  'Advanced Technical Indicators',
  'Pattern Recognition',
  'Market Cycle Analysis',
  'Sentiment Analysis',
  'Custom Alerts',
  'Priority Support'
];

const PricingPlans: React.FC = () => {
  const handlePaymentSuccess = (data: any) => {
    console.log('Payment successful:', data);
    // Here you would typically:
    // 1. Verify the payment with your backend
    // 2. Grant access to the purchased features
    // 3. Show a success message
    alert('Thank you for your subscription! You will receive an email with access details.');
  };

  return (
    <PayPalScriptProvider options={{ 
      // IMPORTANT: Replace this with your actual PayPal client ID
      "client-id": "YOUR_LIVE_PAYPAL_CLIENT_ID",
      currency: "USD",
      intent: "subscription"
    }}>
      <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 mt-8">
        <h2 className="text-3xl font-bold text-white text-center mb-4">
          Unlock Premium AI Analysis
        </h2>
        <p className="text-center text-white/80 mb-8">
          Get unlimited access to advanced AI predictions and market analysis
        </p>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-white/5 rounded-xl p-8 backdrop-blur-sm border border-white/10 hover:border-purple-500/50 transition-all duration-300">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2">
                  <Brain className="w-6 h-6 text-purple-400" />
                  <Zap className="w-6 h-6 text-blue-400" />
                  <Sparkles className="w-6 h-6 text-yellow-400" />
                </div>
                <h3 className="text-2xl font-bold text-white">Premium AI Suite</h3>
              </div>
              <div className="text-right">
                <p className="text-4xl font-bold text-white">
                  $29.99
                  <span className="text-sm font-normal text-gray-400">/month</span>
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                  <span className="text-white">{feature}</span>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <PayPalButtons
                style={{ 
                  layout: "horizontal",
                  color: "gold",
                  shape: "rect",
                  label: "subscribe"
                }}
                createSubscription={(data, actions) => {
                  return actions.subscription.create({
                    'plan_id': 'YOUR_PAYPAL_PLAN_ID' // Replace with your PayPal plan ID
                  });
                }}
                onApprove={(data, actions) => {
                  console.log('Subscription approved:', data);
                  handlePaymentSuccess(data);
                  return Promise.resolve();
                }}
              />

              <div className="flex items-center justify-center gap-4 text-white/60 text-sm">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>14-day money-back guarantee</span>
                </div>
                <div className="flex items-center gap-1">
                  <LineChart className="w-4 h-4" />
                  <span>Cancel anytime</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <p className="text-white/60 text-sm">
              By subscribing, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </div>
      </div>
    </PayPalScriptProvider>
  );
};

export default PricingPlans;