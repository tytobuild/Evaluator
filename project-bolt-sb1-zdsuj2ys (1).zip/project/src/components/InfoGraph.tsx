import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Brain, TrendingUp, TrendingDown } from 'lucide-react';

interface InfoGraphProps {
  price: number;
  change24h: number;
  marketCap: number;
  volume: number;
}

const InfoGraph: React.FC<InfoGraphProps> = ({ price, change24h, marketCap, volume }) => {
  // Calculate relative metrics for visualization
  const volumeToMarketCap = (volume / marketCap) * 100;
  const priceImpact = Math.abs(change24h) * (volume / marketCap) * 100;
  const marketStrength = (volume / marketCap) * Math.abs(change24h) * 100;

  const data = [
    {
      name: 'Volume/Cap Ratio',
      value: volumeToMarketCap,
      fill: '#8884d8'
    },
    {
      name: 'Price Impact',
      value: priceImpact,
      fill: change24h >= 0 ? '#4ade80' : '#ef4444'
    },
    {
      name: 'Market Strength',
      value: marketStrength,
      fill: '#a855f7'
    }
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-900/90 backdrop-blur-sm border border-gray-700 rounded-lg p-3">
          <p className="text-white">{label}</p>
          <p className="text-white font-medium">
            {payload[0].value.toFixed(2)}%
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Brain className="w-7 h-7 text-purple-400" />
          <h2 className="text-3xl font-bold text-white drop-shadow-lg">Market Metrics Analysis</h2>
        </div>
        <div className="flex items-center gap-2">
          {change24h >= 0 ? (
            <TrendingUp className="w-5 h-5 text-green-400" />
          ) : (
            <TrendingDown className="w-5 h-5 text-red-400" />
          )}
          <span className={`text-sm font-medium ${
            change24h >= 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            {change24h.toFixed(2)}%
          </span>
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis 
              dataKey="name" 
              stroke="rgba(255,255,255,0.7)"
              tick={{ fill: 'rgba(255,255,255,1)', fontSize: 12 }}
            />
            <YAxis
              stroke="rgba(255,255,255,0.7)"
              tick={{ fill: 'rgba(255,255,255,1)', fontSize: 12 }}
              unit="%"
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="value" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="bg-white/5 rounded-lg p-3">
          <p className="text-white font-medium text-lg mb-2">Volume/Cap Ratio</p>
          <p className="text-white font-medium mt-1">
            {volumeToMarketCap.toFixed(2)}%
          </p>
          <p className="text-white/80 text-sm mt-1">
            Trading volume relative to market cap
          </p>
        </div>
        <div className="bg-white/5 rounded-lg p-3">
          <p className="text-white font-medium text-lg mb-2">Price Impact</p>
          <p className={`font-medium mt-1 ${
            change24h >= 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            {priceImpact.toFixed(2)}%
          </p>
          <p className="text-white/80 text-sm mt-1">
            Price movement impact on market
          </p>
        </div>
        <div className="bg-white/5 rounded-lg p-3">
          <p className="text-white font-medium text-lg mb-2">Market Strength</p>
          <p className="text-purple-400 font-medium mt-1">
            {marketStrength.toFixed(2)}%
          </p>
          <p className="text-white/80 text-sm mt-1">
            Overall market momentum indicator
          </p>
        </div>
      </div>
    </div>
  );
};

export default InfoGraph;