import React, { useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface PriceChartProps {
  data: { timestamp: number; price: number }[];
}

const PriceChart: React.FC<PriceChartProps> = ({ data }) => {
  const processedData = useMemo(() => {
    if (!data || data.length === 0) return [];
    
    // Sort data chronologically
    const sortedData = [...data].sort((a, b) => a.timestamp - b.timestamp);
    
    // Get the time range
    const timeRange = sortedData[sortedData.length - 1].timestamp - sortedData[0].timestamp;
    const dayRange = timeRange / (1000 * 60 * 60 * 24);
    
    // Calculate appropriate data resolution
    let interval = 1;
    
    if (dayRange >= 300) { // 1y - daily points
      interval = Math.floor(sortedData.length / 365);
    } else if (dayRange >= 25) { // 1m - hourly points
      interval = Math.floor(sortedData.length / 720);
    } else { // 1d - 5-minute points
      interval = Math.floor(sortedData.length / 288);
    }
    
    // Ensure we have enough data points
    interval = Math.max(1, interval);
    
    return sortedData.filter((_, index) => index % interval === 0);
  }, [data]);

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const timeRange = processedData.length > 1 
      ? processedData[processedData.length - 1].timestamp - processedData[0].timestamp 
      : 0;
    const dayRange = timeRange / (1000 * 60 * 60 * 24);

    if (dayRange <= 1) { // 24H
      return date.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
    } else if (dayRange <= 31) { // 30D
      return date.toLocaleDateString([], {
        month: 'short',
        day: 'numeric'
      });
    } else { // 1Y
      return date.toLocaleDateString([], {
        month: 'short',
        year: '2-digit'
      });
    }
  };

  const formatPrice = (price: number) => {
    if (price >= 1000) {
      return `$${price.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
    } else if (price >= 1) {
      return `$${price.toFixed(2)}`;
    } else if (price >= 0.01) {
      return `$${price.toFixed(4)}`;
    } else {
      return `$${price.toFixed(8)}`;
    }
  };

  const calculateDomain = () => {
    if (!processedData || processedData.length === 0) return [0, 1];
    
    const prices = processedData.map(d => d.price);
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const padding = (max - min) * 0.05;
    
    return [min - padding, max + padding];
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const currentPrice = payload[0].value;
      const startPrice = processedData[0]?.price || currentPrice;
      const change = ((currentPrice - startPrice) / startPrice) * 100;
      const isPositive = change >= 0;
      
      return (
        <div className="bg-gray-900/90 backdrop-blur-sm border border-gray-700 rounded-lg p-3 shadow-xl">
          <p className="text-gray-400 text-sm mb-1">{formatDate(label)}</p>
          <p className="text-white font-medium">{formatPrice(currentPrice)}</p>
          <p className={`text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
            {isPositive ? '+' : ''}{change.toFixed(2)}%
          </p>
        </div>
      );
    }
    return null;
  };

  if (!processedData || processedData.length === 0) {
    return (
      <div className="h-[400px] flex items-center justify-center">
        <p className="text-gray-400">No data available</p>
      </div>
    );
  }

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={processedData}
          margin={{ top: 10, right: 30, left: 10, bottom: 0 }}
        >
          <defs>
            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#8884d8" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="rgba(255,255,255,0.1)"
            vertical={false}
          />
          <XAxis
            dataKey="timestamp"
            tickFormatter={formatDate}
            stroke="rgba(255,255,255,0.5)"
            tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
            minTickGap={30}
          />
          <YAxis
            stroke="rgba(255,255,255,0.5)"
            tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
            tickFormatter={formatPrice}
            domain={calculateDomain()}
            width={80}
          />
          <Tooltip content={<CustomTooltip />} />
          <Line
            type="monotone"
            dataKey="price"
            stroke="#8884d8"
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4, fill: '#8884d8' }}
            animationDuration={300}
            isAnimationActive={true}
            connectNulls={true}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default PriceChart;