import React from 'react';
import { Brain, TrendingUp, TrendingDown, AlertTriangle, Zap } from 'lucide-react';

const MarketAIAnalyzer: React.FC = () => {
  // Simulated market analysis based on current time
  const getMarketAnalysis = () => {
    const hour = new Date().getHours();
    const dayOfWeek = new Date().getDay();
    
    // Market activity tends to be higher during weekdays and trading hours
    const isActiveHours = hour >= 9 && hour <= 16;
    const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;
    
    return {
      marketCondition: isWeekday && isActiveHours ? 'High Activity' : 'Moderate Activity',
      riskLevel: isWeekday && isActiveHours ? 'Moderate' : 'High',
      trend: Math.random() > 0.5 ? 'bullish' : 'bearish',
      confidence: isWeekday && isActiveHours ? 75 : 60
    };
  };

  const analysis = getMarketAnalysis();

  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-lg p-4 mb-8">
      <div className="flex items-center gap-2 mb-4">
        <Brain className="w-5 h-5 text-purple-400" />
        <h2 className="text-lg font-semibold text-white">Real-Time Market Analysis</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white/5 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Market Activity</span>
            <Zap className="w-4 h-4 text-yellow-400" />
          </div>
          <p className="text-white font-medium mt-1">{analysis.marketCondition}</p>
        </div>

        <div className="bg-white/5 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Current Trend</span>
            {analysis.trend === 'bullish' ? (
              <TrendingUp className="w-4 h-4 text-green-400" />
            ) : (
              <TrendingDown className="w-4 h-4 text-red-400" />
            )}
          </div>
          <p className={`font-medium mt-1 ${
            analysis.trend === 'bullish' ? 'text-green-400' : 'text-red-400'
          }`}>
            {analysis.trend.charAt(0).toUpperCase() + analysis.trend.slice(1)}
          </p>
        </div>

        <div className="bg-white/5 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Risk Level</span>
            <AlertTriangle className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-white font-medium mt-1">{analysis.riskLevel}</p>
        </div>

        <div className="bg-white/5 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">AI Confidence</span>
            <Brain className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-purple-500 rounded-full"
                style={{ width: `${analysis.confidence}%` }}
              />
            </div>
            <span className="text-white font-medium">{analysis.confidence}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketAIAnalyzer;