import React, { useState } from 'react';
import { Search, Loader } from 'lucide-react';
import { searchCrypto, getCryptoData, getHistoricalData } from './api';
import AIAnalysis from './components/AIAnalysis';
import InfoGraph from './components/InfoGraph';
import { CryptoData } from './types';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setError('Please enter a cryptocurrency name');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const results = await searchCrypto(searchQuery);
      if (results.length > 0) {
        const cryptoData = await getCryptoData(results[0].id);
        const newSelectedCrypto = {
          ...results[0],
          ...cryptoData,
          current_price: cryptoData.usd,
          price_change_percentage_24h: cryptoData.usd_24h_change || 0,
          market_cap: cryptoData.usd_market_cap || 0,
          total_volume: cryptoData.usd_24h_vol || 0
        };
        setSelectedCrypto(newSelectedCrypto);
      } else {
        setError('No cryptocurrency found with that name');
        setSelectedCrypto(null);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch cryptocurrency data';
      setError(errorMessage);
      setSelectedCrypto(null);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !loading) {
      handleSearch();
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Radial gradient overlay for center illumination */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at center, rgba(255,255,255,0.15) 0%, rgba(0,0,0,0) 70%)',
          mixBlendMode: 'overlay'
        }}
      />
      
      {/* Main background with enhanced lighting */}
      <div 
        className="relative min-h-screen bg-gradient-to-br from-blue-950/50 via-blue-800/40 to-blue-600/30"
        style={{
          backgroundImage: `
            radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, transparent 60%),
            linear-gradient(to bottom right, rgba(23, 37, 84, 0.4), rgba(30, 58, 138, 0.3)), 
            url('https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=100&w=2000&brightness=120')
          `,
          backgroundBlend: 'soft-light',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'brightness(1.2)',
        }}
      >
        {/* Content */}
        <div className="relative container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl font-bold text-white text-center mb-8 drop-shadow-lg">
              AI Crypto Evaluator
            </h1>

            <div className="bg-white/5 backdrop-blur-lg rounded-lg p-6 mb-8 shadow-xl">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter cryptocurrency name..."
                  className="flex-1 px-4 py-2 rounded-lg bg-white/10 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-inner"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={loading}
                />
                <button
                  onClick={handleSearch}
                  className={`px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 transition-colors shadow-lg ${
                    loading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700'
                  }`}
                  disabled={loading}
                >
                  {loading ? <Loader className="animate-spin" /> : <Search />}
                  Search
                </button>
              </div>
              {error && (
                <div className="mt-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg">
                  <p className="text-white text-sm">{error}</p>
                </div>
              )}
            </div>

            {selectedCrypto && (
              <div className="space-y-6">
                <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 shadow-xl">
                  <h2 className="text-3xl font-bold text-white mb-6 drop-shadow-lg">Market Stats</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-white/5 rounded-lg shadow-lg">
                      <p className="text-white font-medium">Price</p>
                      <p className="text-xl text-white">
                        ${selectedCrypto.current_price?.toLocaleString(undefined, { 
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 8
                        })}
                      </p>
                    </div>
                    <div className="p-4 bg-white/5 rounded-lg shadow-lg">
                      <p className="text-white font-medium">24h Change</p>
                      <p className={`text-xl ${(selectedCrypto.price_change_percentage_24h || 0) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {(selectedCrypto.price_change_percentage_24h || 0).toFixed(2)}%
                      </p>
                    </div>
                    <div className="p-4 bg-white/5 rounded-lg shadow-lg">
                      <p className="text-white font-medium">Market Cap</p>
                      <p className="text-xl text-white">
                        ${(selectedCrypto.market_cap || 0).toLocaleString()}
                      </p>
                    </div>
                    <div className="p-4 bg-white/5 rounded-lg shadow-lg">
                      <p className="text-white font-medium">24h Volume</p>
                      <p className="text-xl text-white">
                        ${(selectedCrypto.total_volume || 0).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                <AIAnalysis
                  price={selectedCrypto.current_price}
                  change24h={selectedCrypto.price_change_percentage_24h}
                />

                <InfoGraph 
                  price={selectedCrypto.current_price}
                  change24h={selectedCrypto.price_change_percentage_24h}
                  marketCap={selectedCrypto.market_cap}
                  volume={selectedCrypto.total_volume}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;