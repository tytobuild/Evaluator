import axios, { AxiosError } from 'axios';
import { CryptoData, HistoricalData } from './types';

const BASE_URL = 'https://api.coingecko.com/api/v3';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000, // Increased timeout
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Secure': 'true'
  }
});

// Enhanced retry logic with exponential backoff
const withRetry = async (fn: () => Promise<any>, retries = 3, initialDelay = 1000) => {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      
      if (attempt === retries) break;
      
      const isRateLimit = axios.isAxiosError(error) && error.response?.status === 429;
      const isNetworkError = axios.isAxiosError(error) && !error.response;
      
      if (!isRateLimit && !isNetworkError) throw error;
      
      const delay = isRateLimit
        ? initialDelay * Math.pow(2, attempt) // Exponential backoff for rate limits
        : initialDelay; // Linear delay for network issues
        
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  throw lastError;
};

// Enhanced error messages
const getErrorMessage = (error: unknown): string => {
  if (axios.isAxiosError(error)) {
    if (error.response?.status === 429) {
      return 'Rate limit exceeded. Please try again in a moment.';
    }
    if (error.response?.status === 404) {
      return 'Cryptocurrency not found.';
    }
    if (error.code === 'ECONNABORTED') {
      return 'Request timed out. Please check your connection.';
    }
    if (!error.response) {
      return 'Network error. Please check your connection and try again.';
    }
    return error.response.data?.error || 'An error occurred while fetching data.';
  }
  return 'An unexpected error occurred.';
};

export const searchCrypto = async (query: string): Promise<CryptoData[]> => {
  try {
    const response = await withRetry(() => 
      api.get('/search', {
        params: { query }
      })
    );
    return response.data.coins.slice(0, 10);
  } catch (error) {
    throw new Error(getErrorMessage(error));
  }
};

export const getCryptoData = async (id: string): Promise<CryptoData> => {
  try {
    const response = await withRetry(() =>
      api.get('/simple/price', {
        params: {
          ids: id,
          vs_currencies: 'usd',
          include_market_cap: true,
          include_24hr_vol: true,
          include_24hr_change: true,
          include_last_updated_at: true
        }
      })
    );
    
    if (!response.data[id]) {
      throw new Error('Cryptocurrency not found');
    }
    
    return response.data[id];
  } catch (error) {
    throw new Error(getErrorMessage(error));
  }
};

export const getHistoricalData = async (
  id: string,
  timeframe: string
): Promise<HistoricalData> => {
  try {
    let days: string;
    let interval: string;

    // Configure timeframe parameters
    switch (timeframe) {
      case '1d':
        days = '1';
        interval = 'minute';
        break;
      case '1m':
        days = '30';
        interval = 'hourly';
        break;
      case '1y':
        days = '365';
        interval = 'daily';
        break;
      default:
        days = '1';
        interval = 'minute';
    }

    const response = await withRetry(() =>
      api.get(`/coins/${id}/market_chart`, {
        params: {
          vs_currency: 'usd',
          days,
          interval
        }
      })
    );

    // Validate response data
    if (!response.data?.prices || !Array.isArray(response.data.prices)) {
      throw new Error('Invalid data received from server');
    }

    return response.data;
  } catch (error) {
    throw new Error(getErrorMessage(error));
  }
};